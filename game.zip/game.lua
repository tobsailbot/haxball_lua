local alexgames = require("alexgames")
local core = require("game_core")
local draw = require("game_draw")

local FPS = 144
local MS_PER_FRAME = 1000/FPS

function update(dt_ms)
    local dt = dt_ms / 1000.0
    core.update_physics(dt)
    draw.render(core.state)
end

function handle_key_evt(evt_id, code)
    local is_pressed = (evt_id == "keydown")

    -- Jugador 1 (Rojo)
    if code == "KeyW" then core.state.players[1].up = is_pressed
    elseif code == "KeyS" then core.state.players[1].down = is_pressed
    elseif code == "KeyA" then core.state.players[1].left = is_pressed
    elseif code == "KeyD" then core.state.players[1].right = is_pressed
    elseif code == "Space" then core.state.players[1].kicking = is_pressed
    
    -- Jugador 2 (Azul)
    elseif code == "ArrowUp" then core.state.players[2].up = is_pressed
    elseif code == "ArrowDown" then core.state.players[2].down = is_pressed
    elseif code == "ArrowLeft" then core.state.players[2].left = is_pressed
    elseif code == "ArrowRight" then core.state.players[2].right = is_pressed
    elseif code == "ShiftRight" then core.state.players[2].kicking = is_pressed
    end
    
    return true
end

local left_touch_id = nil

function handle_touch_evt(evt_id, touches)
    local p1 = core.state.players[1]
    
    p1.kicking = false
    local found_left_touch = false

    for _, touch in ipairs(touches) do
        -- Evaluar toque en la mitad derecha (Patear)
        if touch.x >= 400 then
            p1.kicking = true
        else
            -- Evaluar toque en la mitad izquierda (Movimiento Flotante)
            local t_id = touch.id or touch.identifier or "single_touch"
            
            if not p1.pad_active then
                p1.pad_active = true
                p1.pad_origin.x = touch.x
                p1.pad_origin.y = touch.y
                left_touch_id = t_id
            end
            
            if left_touch_id == t_id then
                found_left_touch = true
                
                local dx = touch.x - p1.pad_origin.x
                local dy = touch.y - p1.pad_origin.y
                local dist = math.sqrt(dx*dx + dy*dy)
                local pad_radius = 70 
                
                if dist > 0 then
                    local intensity = math.min(dist, pad_radius) / pad_radius
                    p1.pad_vec.x = (dx / dist) * intensity
                    p1.pad_vec.y = (dy / dist) * intensity
                else
                    p1.pad_vec.x = 0
                    p1.pad_vec.y = 0
                end
            end
        end
    end
    
    -- Restablecer el joystick si no se está tocando la zona
    if not found_left_touch then
        p1.pad_active = false
        p1.pad_vec.x = 0
        p1.pad_vec.y = 0
        left_touch_id = nil
    end
    
    return true
end

function start_game()
    alexgames.set_status_msg("Fútbol de mesa - Jugador 1 (Táctil o WASD) | Jugador 2 (Flechas)")
    alexgames.enable_evt("key")
    alexgames.enable_evt("touch") 
    alexgames.set_timer_update_ms(MS_PER_FRAME)
end